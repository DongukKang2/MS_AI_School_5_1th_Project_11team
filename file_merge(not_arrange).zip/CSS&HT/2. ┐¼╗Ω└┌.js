const height = 181;
const goodWeight = (height - 100) * 0.9;

console.log("당신의 키는", height, "cm이며 적정체중은", goodWeight, "입니다.")

console.log("당신의 키는 ${height}cm이며 적정체중은 ${goodWeight}kg입니다.");
