module.exports = {
    jwtsecret: "jwt_secret_key_9312",
    host: "3.39.174.171",
    user: "coha",
    port: "3306",
    password: "Battle11@2024",
    database: "NearFoodMap",
};