console.log('module_1 실행됨');

module.exports = {
    a: 1
};